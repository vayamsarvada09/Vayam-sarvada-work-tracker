#!/usr/bin/env python3
import os
import shutil
import subprocess
import zipfile

def create_project_zip():
    os.makedirs('public', exist_ok=True)
    main_target = os.path.abspath('public/vayam-sarvada-tracker.zip')
    
    if os.path.exists(main_target):
        try:
            os.remove(main_target)
        except Exception:
            pass

    # Use standard Unix zip to guarantee proper directory entries and file permissions
    zip_cmd = [
        'zip', '-r', main_target, '.',
        '-x',
        'node_modules/*',
        '.git/*',
        'dist/*',
        '.gradle/*',
        'build/*',
        '.cache/*',
        'public/vayam-sarvada-tracker.zip',
        '*/build/*',
        '*~',
        '*.pyc'
    ]

    try:
        res = subprocess.run(zip_cmd, cwd=os.getcwd(), capture_output=True, text=True, check=True)
        print("Unix zip command succeeded.")
    except Exception as e:
        print("Unix zip command failed, falling back to python zipfile with explicit directory records:", e)
        # Python fallback with EXPLICIT directory records
        EXCLUDE_DIRS = {'node_modules', '.git', 'dist', '.gradle', 'build', '.cache'}
        EXCLUDE_FILES = {'vayam-sarvada-tracker.zip'}
        with zipfile.ZipFile(main_target, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk('.'):
                dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS and d != '.git']
                if any(x in root for x in ['/build', '\\build', '/.gradle', '/node_modules', '/dist', '/.git']):
                    continue
                # Write directory entry with proper directory attribute
                for d in dirs:
                    d_path = os.path.relpath(os.path.join(root, d), '.') + '/'
                    zinfo = zipfile.ZipInfo(d_path)
                    zinfo.external_attr = 0o755 << 16 | 0x10  # directory attribute
                    zipf.writestr(zinfo, '')
                for f in files:
                    if f in EXCLUDE_FILES or f.endswith('.pyc'):
                        continue
                    full_path = os.path.join(root, f)
                    if 'vayam-sarvada-tracker.zip' in full_path:
                        continue
                    rel_path = os.path.relpath(full_path, '.')
                    zipf.write(full_path, rel_path)

    # Copy to dist if dist exists
    if os.path.isdir('dist'):
        shutil.copyfile(main_target, 'dist/vayam-sarvada-tracker.zip')

    # Verification of ZIP contents
    with zipfile.ZipFile(main_target, 'r') as z:
        names = z.namelist()
        dirs = [n for n in names if n.endswith('/')]
        has_android_dir = 'android/' in dirs or any(n.startswith('android/') for n in names)
        has_workflow = '.github/workflows/build-apk.yml' in names
        has_gradlew = 'android/gradlew' in names
        has_manifest = 'android/app/src/main/AndroidManifest.xml' in names
        print(f"Verified ZIP: {len(names)} entries, {len(dirs)} directories.")
        print(f" - android/ directory present: {has_android_dir}")
        print(f" - .github/workflows/build-apk.yml present: {has_workflow}")
        print(f" - android/gradlew present: {has_gradlew}")
        print(f" - AndroidManifest.xml present: {has_manifest}")
        if not (has_android_dir and has_workflow and has_gradlew and has_manifest):
            raise RuntimeError("Generated ZIP is missing crucial Android or GitHub workflow files!")

    size = os.path.getsize(main_target)
    print(f"Successfully generated {main_target} ({size} bytes)")

if __name__ == '__main__':
    create_project_zip()
