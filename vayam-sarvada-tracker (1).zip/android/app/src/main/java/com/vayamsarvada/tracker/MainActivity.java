package com.vayamsarvada.tracker;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
