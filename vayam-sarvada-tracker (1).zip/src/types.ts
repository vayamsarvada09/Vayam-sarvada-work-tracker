export type PlatformId = 'insta' | 'yt';

export interface PostSlot {
  id: string; // e.g. "insta-11:00 AM"
  platform: PlatformId;
  time: string; // e.g. "11:00 AM"
  completed: boolean;
  completedAt?: string;
  note?: string;
  driveLink?: string;
}

export interface DayStreak {
  currentStreak: number;
  lastCompletedDate: string | null;
}
