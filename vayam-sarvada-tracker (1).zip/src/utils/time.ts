// Helper to parse times like "11:00 AM", "1:00 PM", "6:00 PM", etc.
export function parseTimeToToday(timeStr: string, baseDate = new Date()): Date {
  const match = timeStr.trim().match(/^(\d+):(\d+)\s*(AM|PM)$/i);
  if (!match) return baseDate;

  let hours = parseInt(match[1], 10);
  const minutes = parseInt(match[2], 10);
  const meridiem = match[3].toUpperCase();

  if (meridiem === 'PM' && hours < 12) {
    hours += 12;
  } else if (meridiem === 'AM' && hours === 12) {
    hours = 0;
  }

  const d = new Date(baseDate);
  d.setHours(hours, minutes, 0, 0);
  return d;
}

export function getSlotStatus(timeStr: string, completed: boolean, now = new Date()): 'completed' | 'active' | 'upcoming' | 'passed' {
  if (completed) return 'completed';

  const slotTime = parseTimeToToday(timeStr, now);
  const diffMinutes = (slotTime.getTime() - now.getTime()) / (1000 * 60);

  // If within 30 minutes before or 60 minutes after scheduled slot
  if (diffMinutes >= -60 && diffMinutes <= 30) {
    return 'active';
  }
  if (diffMinutes < -60) {
    return 'passed';
  }
  return 'upcoming';
}
