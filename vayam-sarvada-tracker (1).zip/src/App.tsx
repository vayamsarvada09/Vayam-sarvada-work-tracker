import { useState, useEffect, useRef, type FormEvent } from 'react';
import confetti from 'canvas-confetti';
import { RotateCcw, CheckCheck, Sparkles, Volume2, VolumeX, Plus, Trash2, HardDrive, Download, Loader2, ExternalLink, Check, Share2 } from 'lucide-react';
import { PlatformId, PostSlot, DayStreak } from './types';
import { PlatformCard } from './components/PlatformCard';
import { Header } from './components/Header';
import { ResetModal } from './components/ResetModal';
import { playCheckSound, playCelebrationSound } from './utils/audio';

const DEFAULT_TIMES = ["11:00 AM", "1:00 PM", "6:00 PM", "9:00 PM", "11:00 PM"];
const STREAK_KEY = 'vayam_sarvada_streak';
const SOUND_MUTED_KEY = 'vayam_sarvada_muted';
const CUSTOM_TIMES_KEY = 'vayam_sarvada_custom_times';

export default function App() {
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [isMuted, setIsMuted] = useState<boolean>(() => {
    return localStorage.getItem(SOUND_MUTED_KEY) === 'true';
  });
  const [showTimeManager, setShowTimeManager] = useState(false);
  const [newTimeInput, setNewTimeInput] = useState('');
  const [times, setTimes] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(CUSTOM_TIMES_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // fallback
    }
    return DEFAULT_TIMES;
  });

  // Streaks
  const [streakData, setStreakData] = useState<DayStreak>(() => {
    try {
      const saved = localStorage.getItem(STREAK_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return { currentStreak: 0, lastCompletedDate: null };
  });

  // Slots state
  const [slots, setSlots] = useState<PostSlot[]>(() => {
    const initial: PostSlot[] = [];
    const platforms: PlatformId[] = ['insta', 'yt'];

    platforms.forEach((platform) => {
      times.forEach((time) => {
        const id = `${platform}-${time}`;
        // Read directly from legacy localStorage keys as requested:
        const isChecked = localStorage.getItem(id) === 'true';
        const savedNote = localStorage.getItem(`${id}-note`) || undefined;
        const savedDoneAt = localStorage.getItem(`${id}-doneAt`) || undefined;

        initial.push({
          id,
          platform,
          time,
          completed: isChecked,
          completedAt: isChecked ? savedDoneAt : undefined,
          note: savedNote,
        });
      });
    });

    return initial;
  });

  // Track if previous allComplete state to trigger celebration only on the transition to 100%
  const hasCelebratedRef = useRef(false);

  // Live timer tick every 1000ms
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Update mute preference
  const toggleSound = () => {
    const next = !isMuted;
    setIsMuted(next);
    localStorage.setItem(SOUND_MUTED_KEY, String(next));
  };

  // Toggle single slot
  const handleToggle = (id: string, checked: boolean) => {
    const now = new Date();
    const timeFormatted = now.toLocaleTimeString([], {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });

    setSlots((prev) => {
      const next = prev.map((s) => {
        if (s.id === id) {
          return {
            ...s,
            completed: checked,
            completedAt: checked ? timeFormatted : undefined,
          };
        }
        return s;
      });

      // Save directly to localStorage using exact legacy key format
      localStorage.setItem(id, String(checked));
      if (checked) {
        localStorage.setItem(`${id}-doneAt`, timeFormatted);
        if (!isMuted) playCheckSound();
      } else {
        localStorage.removeItem(`${id}-doneAt`);
      }

      // Check if all are now completed
      const allCompleted = next.every((s) => s.completed);
      if (allCompleted && !hasCelebratedRef.current) {
        hasCelebratedRef.current = true;
        triggerCelebration();
      } else if (!allCompleted) {
        hasCelebratedRef.current = false;
      }

      return next;
    });
  };

  // Update note
  const handleUpdateNote = (id: string, note: string) => {
    setSlots((prev) =>
      prev.map((s) => (s.id === id ? { ...s, note } : s))
    );
    if (note.trim()) {
      localStorage.setItem(`${id}-note`, note);
    } else {
      localStorage.removeItem(`${id}-note`);
    }
  };

  // Batch toggle for a platform
  const handleBatchToggle = (platformId: PlatformId, complete: boolean) => {
    const now = new Date();
    const timeFormatted = now.toLocaleTimeString([], {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });

    setSlots((prev) => {
      const next = prev.map((s) => {
        if (s.platform === platformId) {
          localStorage.setItem(s.id, String(complete));
          if (complete) {
            localStorage.setItem(`${s.id}-doneAt`, timeFormatted);
          } else {
            localStorage.removeItem(`${s.id}-doneAt`);
          }
          return {
            ...s,
            completed: complete,
            completedAt: complete ? timeFormatted : undefined,
          };
        }
        return s;
      });

      const allCompleted = next.every((s) => s.completed);
      if (allCompleted && !hasCelebratedRef.current) {
        hasCelebratedRef.current = true;
        triggerCelebration();
      } else if (!allCompleted) {
        hasCelebratedRef.current = false;
      }

      if (complete && !isMuted) playCheckSound();
      return next;
    });
  };

  // Trigger Confetti Celebration and Streak increment
  const triggerCelebration = () => {
    if (!isMuted) playCelebrationSound();

    try {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#38bdf8', '#22c55e', '#ec4899', '#f59e0b', '#a855f7'],
      });
    } catch {
      // fallback if confetti fails
    }

    // Update streak if not completed yet today
    const todayStr = new Date().toDateString();
    setStreakData((prev) => {
      if (prev.lastCompletedDate === todayStr) {
        return prev;
      }
      const newStreak = prev.currentStreak + 1;
      const updated: DayStreak = {
        currentStreak: newStreak,
        lastCompletedDate: todayStr,
      };
      localStorage.setItem(STREAK_KEY, JSON.stringify(updated));
      return updated;
    });
  };

  // Reset for new day (as in the original user prompt, resets checkmarks)
  const handleResetForNewDay = () => {
    slots.forEach((s) => {
      localStorage.removeItem(s.id);
      localStorage.removeItem(`${s.id}-doneAt`);
      localStorage.removeItem(`${s.id}-note`);
    });

    setSlots((prev) =>
      prev.map((s) => ({
        ...s,
        completed: false,
        completedAt: undefined,
        note: undefined,
      }))
    );
    hasCelebratedRef.current = false;
  };

  // Quick action: Complete all
  const handleCompleteAll = () => {
    const now = new Date();
    const timeFormatted = now.toLocaleTimeString([], {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });

    slots.forEach((s) => {
      localStorage.setItem(s.id, 'true');
      localStorage.setItem(`${s.id}-doneAt`, timeFormatted);
    });

    setSlots((prev) =>
      prev.map((s) => ({
        ...s,
        completed: true,
        completedAt: timeFormatted,
      }))
    );

    triggerCelebration();
  };

  // Manage custom times if user wants to add/remove hours
  const handleAddTime = (e: FormEvent) => {
    e.preventDefault();
    const trimmed = newTimeInput.trim();
    if (!trimmed) return;
    if (times.includes(trimmed)) {
      setNewTimeInput('');
      return;
    }

    const updated = [...times, trimmed];
    setTimes(updated);
    localStorage.setItem(CUSTOM_TIMES_KEY, JSON.stringify(updated));
    setNewTimeInput('');

    // Rebuild slots
    const newSlots: PostSlot[] = [];
    (['insta', 'yt'] as PlatformId[]).forEach((platform) => {
      updated.forEach((time) => {
        const id = `${platform}-${time}`;
        const isChecked = localStorage.getItem(id) === 'true';
        newSlots.push({
          id,
          platform,
          time,
          completed: isChecked,
          completedAt: isChecked ? localStorage.getItem(`${id}-doneAt`) || undefined : undefined,
          note: localStorage.getItem(`${id}-note`) || undefined,
        });
      });
    });
    setSlots(newSlots);
  };

  const handleRemoveTime = (timeToRemove: string) => {
    if (times.length <= 1) return;
    const updated = times.filter((t) => t !== timeToRemove);
    setTimes(updated);
    localStorage.setItem(CUSTOM_TIMES_KEY, JSON.stringify(updated));

    // Clear removed keys
    (['insta', 'yt'] as PlatformId[]).forEach((platform) => {
      const id = `${platform}-${timeToRemove}`;
      localStorage.removeItem(id);
      localStorage.removeItem(`${id}-doneAt`);
      localStorage.removeItem(`${id}-note`);
    });

    setSlots((prev) => prev.filter((s) => s.time !== timeToRemove));
  };

  const handleRestoreDefaultTimes = () => {
    setTimes(DEFAULT_TIMES);
    localStorage.removeItem(CUSTOM_TIMES_KEY);

    const newSlots: PostSlot[] = [];
    (['insta', 'yt'] as PlatformId[]).forEach((platform) => {
      DEFAULT_TIMES.forEach((time) => {
        const id = `${platform}-${time}`;
        const isChecked = localStorage.getItem(id) === 'true';
        newSlots.push({
          id,
          platform,
          time,
          completed: isChecked,
          completedAt: isChecked ? localStorage.getItem(`${id}-doneAt`) || undefined : undefined,
          note: localStorage.getItem(`${id}-note`) || undefined,
        });
      });
    });
    setSlots(newSlots);
  };

  const instaSlots = slots.filter((s) => s.platform === 'insta');
  const ytSlots = slots.filter((s) => s.platform === 'yt');

  const totalSlots = slots.length;
  const completedTotal = slots.filter((s) => s.completed).length;
  const isAllComplete = completedTotal === totalSlots && totalSlots > 0;

  const [isDownloadingZip, setIsDownloadingZip] = useState(false);
  const [zipDownloadSuccess, setZipDownloadSuccess] = useState(false);

  const handleDownloadZip = async () => {
    if (isDownloadingZip) return;
    setIsDownloadingZip(true);

    try {
      // 1. Fetch raw zip bytes from server
      const response = await fetch(`/api/download-zip?t=${Date.now()}`, {
        headers: {
          Accept: 'application/zip',
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error ${response.status}`);
      }

      const buffer = await response.arrayBuffer();
      // 2. Ensure Blob is strictly application/zip to prevent browser content sniffing as HTML
      const zipBlob = new Blob([buffer], { type: 'application/zip' });

      // 3. Trigger genuine .zip download via Object URL
      const objectUrl = window.URL.createObjectURL(zipBlob);
      const tempLink = document.createElement('a');
      tempLink.href = objectUrl;
      tempLink.download = 'vayam-sarvada-tracker.zip';
      tempLink.setAttribute('download', 'vayam-sarvada-tracker.zip');
      document.body.appendChild(tempLink);
      tempLink.click();

      setTimeout(() => {
        document.body.removeChild(tempLink);
        window.URL.revokeObjectURL(objectUrl);
      }, 15000);

      setZipDownloadSuccess(true);
      setTimeout(() => setZipDownloadSuccess(false), 4000);
    } catch (err) {
      console.warn('Direct Blob download failed, falling back to top-level link:', err);
      window.open('/api/download-zip', '_blank');
    } finally {
      setIsDownloadingZip(false);
    }
  };

  const handleShareZipDirectly = async () => {
    try {
      setIsDownloadingZip(true);
      const response = await fetch(`/api/download-zip?t=${Date.now()}`);
      const buffer = await response.arrayBuffer();
      const file = new File([buffer], 'vayam-sarvada-tracker.zip', {
        type: 'application/zip',
      });

      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          title: 'Vayam Sarvada Tracker Project ZIP',
          text: 'Complete project ZIP for Vayam Sarvada Tracker (Android + GitHub Actions)',
          files: [file],
        });
        return;
      }
      handleDownloadZip();
    } catch (err: unknown) {
      if ((err as Error)?.name !== 'AbortError') {
        handleDownloadZip();
      }
    } finally {
      setIsDownloadingZip(false);
    }
  };

  const handleBackupToDrive = async () => {
    const today = new Date().toLocaleDateString(undefined, {
      weekday: 'long',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });

    const report =
      `VAYAM SARVADA POST TRACKER - DAILY REPORT\n` +
      `Date: ${today}\n` +
      `Current Streak: ${streakData.currentStreak} Days\n` +
      `Progress: ${completedTotal}/${totalSlots} published\n\n` +
      `--- INSTAGRAM REELS ---\n` +
      instaSlots
        .map(
          (s) =>
            `[${s.completed ? 'COMPLETED' : 'PENDING'}] ${s.time}` +
            (s.completedAt ? ` (at ${s.completedAt})` : '') +
            (s.note ? `\n  Note/Link: ${s.note}` : '')
        )
        .join('\n') +
      `\n\n--- YOUTUBE SHORTS ---\n` +
      ytSlots
        .map(
          (s) =>
            `[${s.completed ? 'COMPLETED' : 'PENDING'}] ${s.time}` +
            (s.completedAt ? ` (at ${s.completedAt})` : '') +
            (s.note ? `\n  Note/Link: ${s.note}` : '')
        )
        .join('\n') +
      `\n\nGenerated from Vayam Sarvada Post Tracker`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: `Vayam Sarvada Tracker - ${today}`,
          text: report,
        });
        return;
      } catch (err: unknown) {
        if ((err as Error)?.name === 'AbortError') return;
      }
    }

    // Fallback: download txt file which on phone can be saved to Google Drive
    const blob = new Blob([report], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Vayam-Sarvada-Schedule-${new Date().toISOString().slice(0, 10)}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 p-4 sm:p-6 lg:p-8 flex flex-col items-center justify-start selection:bg-sky-500/30">
      <div className="w-full max-w-3xl">
        {/* Top utility bar */}
        <div className="flex items-center justify-between gap-2 mb-2 text-xs">
          {/* Quick Google Drive Backup / Open & Direct ZIP Download */}
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              id="btn-download-zip"
              onClick={handleDownloadZip}
              disabled={isDownloadingZip}
              title="Download Complete Project ZIP (vayam-sarvada-tracker.zip with Android project & GitHub Actions workflow)"
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded border transition-colors font-medium shadow-sm ${
                zipDownloadSuccess
                  ? 'bg-emerald-950/90 text-emerald-300 border-emerald-600/60'
                  : 'bg-sky-950/90 hover:bg-sky-900 text-sky-200 hover:text-white border-sky-600/60'
              }`}
            >
              {isDownloadingZip ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 text-sky-400 animate-spin" />
                  <span>Preparing .ZIP...</span>
                </>
              ) : zipDownloadSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Downloaded .ZIP!</span>
                </>
              ) : (
                <>
                  <Download className="w-3.5 h-3.5 text-sky-400" />
                  <span>Project ZIP</span>
                </>
              )}
            </button>
            <a
              href="/api/download-zip"
              download="vayam-sarvada-tracker.zip"
              target="_blank"
              rel="noopener noreferrer"
              title="Direct download link (opens in new tab to guarantee genuine .zip download on mobile)"
              className="text-slate-400 hover:text-sky-300 px-2 py-1 rounded bg-slate-800/60 border border-slate-700/50 transition-colors hidden sm:inline-flex items-center gap-1 text-[11px]"
            >
              <ExternalLink className="w-3 h-3 text-sky-400" />
              <span>Direct Link ↗</span>
            </a>
            <button
              type="button"
              id="btn-backup-drive"
              onClick={handleBackupToDrive}
              title="Save / Share schedule to Google Drive"
              className="flex items-center gap-1.5 text-slate-300 hover:text-emerald-400 px-2.5 py-1 rounded bg-slate-800/90 border border-slate-700/70 transition-colors"
            >
              <HardDrive className="w-3.5 h-3.5 text-emerald-400" />
              <span>Save to Drive</span>
            </button>
            <a
              href="https://drive.google.com"
              target="_blank"
              rel="noopener noreferrer"
              title="Open Google Drive App"
              className="text-slate-400 hover:text-slate-200 px-2 py-1 rounded bg-slate-800/60 border border-slate-700/50 transition-colors hidden sm:inline-flex items-center gap-1"
            >
              Drive App ↗
            </a>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowTimeManager(!showTimeManager)}
              className="text-slate-400 hover:text-slate-200 px-2.5 py-1 rounded bg-slate-800/80 border border-slate-700/60 transition-colors"
            >
              {showTimeManager ? 'Close Slot Settings' : 'Customize Times'}
            </button>
            <button
              type="button"
              onClick={toggleSound}
              title={isMuted ? 'Unmute sounds' : 'Mute sounds'}
              className="p-1.5 rounded text-slate-400 hover:text-slate-200 bg-slate-800/80 border border-slate-700/60 transition-colors"
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-sky-400" />}
            </button>
          </div>
        </div>

        {/* Optional Slot Manager */}
        {showTimeManager && (
          <div className="mb-6 p-4 rounded-xl bg-slate-800/90 border border-slate-700 text-sm">
            <h3 className="font-semibold text-slate-200 mb-2">Schedule Time Slots</h3>
            <p className="text-xs text-slate-400 mb-3">
              Standard 5-slot daily schedule. You can add extra slots (e.g. 3:00 PM) or remove any.
            </p>
            <div className="flex flex-wrap gap-2 mb-3">
              {times.map((t) => (
                <div
                  key={t}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-700/80 border border-slate-600 text-xs font-medium text-slate-200"
                >
                  <span>{t}</span>
                  {times.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveTime(t)}
                      className="text-slate-400 hover:text-red-400 ml-1"
                      title={`Remove ${t}`}
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  )}
                </div>
              ))}
            </div>

            <form onSubmit={handleAddTime} className="flex gap-2 items-center">
              <input
                type="text"
                value={newTimeInput}
                onChange={(e) => setNewTimeInput(e.target.value)}
                placeholder="e.g. 3:30 PM"
                className="bg-slate-900 text-slate-100 text-xs px-3 py-2 rounded-lg border border-slate-700 focus:outline-none focus:border-sky-500 w-36"
              />
              <button
                type="submit"
                className="flex items-center gap-1 text-xs font-medium bg-sky-600 hover:bg-sky-500 text-white px-3 py-2 rounded-lg transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Slot
              </button>
              <button
                type="button"
                onClick={handleRestoreDefaultTimes}
                className="text-xs text-slate-400 hover:text-slate-200 ml-auto underline underline-offset-2"
              >
                Reset to Defaults
              </button>
            </form>
          </div>
        )}

        {/* Main Header */}
        <Header
          currentTime={currentTime}
          allSlots={slots}
          streak={streakData.currentStreak}
        />

        {/* Celebratory Banner when 100% complete */}
        {isAllComplete && (
          <div
            id="all-complete-banner"
            className="mb-5 p-4 rounded-xl bg-gradient-to-r from-emerald-950/70 via-slate-900 to-teal-950/70 border border-emerald-500/40 shadow-lg shadow-emerald-500/10 flex items-center justify-between gap-3 animate-in fade-in zoom-in-95 duration-300"
          >
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shrink-0">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-100 text-sm sm:text-base">
                  All {totalSlots} Posts Published Today!
                </h3>
                <p className="text-xs text-emerald-300/80">
                  Great job staying consistent. Today’s streak incremented!
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={triggerCelebration}
              className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-colors shrink-0"
            >
              Replay 🎉
            </button>
          </div>
        )}

        {/* Platform Checklists */}
        <div className="space-y-5">
          {/* Instagram Reels Card */}
          <PlatformCard
            platformId="insta"
            title="📸 Instagram Reels"
            containerId="insta-slots"
            icon="instagram"
            slots={instaSlots}
            currentTime={currentTime}
            onToggle={handleToggle}
            onUpdateNote={handleUpdateNote}
            onBatchToggle={handleBatchToggle}
          />

          {/* YouTube Shorts Card */}
          <PlatformCard
            platformId="yt"
            title="▶️ YouTube Shorts"
            containerId="yt-slots"
            icon="youtube"
            slots={ytSlots}
            currentTime={currentTime}
            onToggle={handleToggle}
            onUpdateNote={handleUpdateNote}
            onBatchToggle={handleBatchToggle}
          />
        </div>

        {/* Footer Action Buttons */}
        <div className="mt-6 flex flex-col sm:flex-row items-center gap-3">
          {/* Quick Mark All Button */}
          {!isAllComplete && (
            <button
              type="button"
              id="btn-mark-all"
              onClick={handleCompleteAll}
              className="w-full sm:w-1/3 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-sm transition-all flex items-center justify-center gap-2 hover:border-slate-600 active:scale-[0.99]"
            >
              <CheckCheck className="w-4 h-4 text-emerald-400" />
              Mark All Done
            </button>
          )}

          {/* Reset for New Day Button - exact equivalent of the user's .reset-btn */}
          <button
            type="button"
            id="reset-btn"
            onClick={() => setIsResetModalOpen(true)}
            className={`w-full ${!isAllComplete ? 'sm:w-2/3' : 'sm:w-full'} py-3 px-4 rounded-xl bg-red-600 hover:bg-red-500 active:bg-red-700 text-white font-bold text-sm tracking-wide transition-all shadow-md shadow-red-950/40 flex items-center justify-center gap-2 active:scale-[0.99] cursor-pointer`}
          >
            <RotateCcw className="w-4 h-4" />
            Reset for New Day
          </button>
        </div>

        {/* Subtle footer credit / info */}
        <footer className="mt-8 text-center text-xs text-slate-500 pb-6">
          <p>Vayam Sarvada Publishing Tracker • Auto-saved locally</p>
        </footer>
      </div>

      {/* Confirmation Modal */}
      <ResetModal
        isOpen={isResetModalOpen}
        onClose={() => setIsResetModalOpen(false)}
        onConfirm={handleResetForNewDay}
      />
    </div>
  );
}
