import React from 'react';
import { Instagram, Youtube, CheckCheck, RotateCcw } from 'lucide-react';
import { PlatformId, PostSlot } from '../types';
import { SlotItem } from './SlotItem';

interface PlatformCardProps {
  platformId: PlatformId;
  title: string;
  containerId: string;
  icon: 'instagram' | 'youtube';
  slots: PostSlot[];
  currentTime: Date;
  onToggle: (id: string, checked: boolean) => void;
  onUpdateNote: (id: string, note: string) => void;
  onBatchToggle: (platformId: PlatformId, complete: boolean) => void;
}

export const PlatformCard: React.FC<PlatformCardProps> = ({
  platformId,
  title,
  containerId,
  icon,
  slots,
  currentTime,
  onToggle,
  onUpdateNote,
  onBatchToggle,
}) => {
  const completedCount = slots.filter((s) => s.completed).length;
  const totalCount = slots.length;
  const percent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;
  const isAllComplete = completedCount === totalCount && totalCount > 0;

  return (
    <div
      id={`platform-card-${platformId}`}
      className="bg-slate-800/90 backdrop-blur-sm rounded-xl p-4 sm:p-5 border border-slate-700/80 shadow-lg shadow-black/20"
    >
      {/* Platform Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-700/60">
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
              icon === 'instagram'
                ? 'bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 text-white shadow-md shadow-rose-500/20'
                : 'bg-red-600 text-white shadow-md shadow-red-600/20'
            }`}
          >
            {icon === 'instagram' ? (
              <Instagram className="w-5 h-5 stroke-[2.2]" />
            ) : (
              <Youtube className="w-5 h-5 stroke-[2.2]" />
            )}
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              {title}
            </h2>
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span>
                {completedCount} of {totalCount} published
              </span>
              <span>•</span>
              <span className={isAllComplete ? 'text-emerald-400 font-semibold' : ''}>
                {percent}% done
              </span>
            </div>
          </div>
        </div>

        {/* Mini progress bar & Quick actions */}
        <div className="flex items-center gap-3">
          <div className="w-24 sm:w-32 bg-slate-700/70 h-2 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-300 ${
                isAllComplete
                  ? 'bg-emerald-500'
                  : icon === 'instagram'
                  ? 'bg-gradient-to-r from-pink-500 to-rose-400'
                  : 'bg-red-500'
              }`}
              style={{ width: `${percent}%` }}
            />
          </div>

          <div className="flex items-center gap-1">
            {completedCount < totalCount ? (
              <button
                type="button"
                id={`btn-complete-all-${platformId}`}
                onClick={() => onBatchToggle(platformId, true)}
                title="Mark all as completed"
                className="p-1.5 text-xs text-slate-400 hover:text-emerald-400 hover:bg-slate-700/50 rounded transition-colors flex items-center gap-1"
              >
                <CheckCheck className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                type="button"
                id={`btn-clear-${platformId}`}
                onClick={() => onBatchToggle(platformId, false)}
                title="Reset this platform"
                className="p-1.5 text-xs text-slate-400 hover:text-amber-400 hover:bg-slate-700/50 rounded transition-colors flex items-center gap-1"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Slots List */}
      <div id={containerId} className="space-y-1">
        {slots.map((slot) => (
          <SlotItem
            key={slot.id}
            slot={slot}
            currentTime={currentTime}
            onToggle={onToggle}
            onUpdateNote={onUpdateNote}
            accentColor={icon === 'instagram' ? 'rose' : 'red'}
          />
        ))}
      </div>
    </div>
  );
};
