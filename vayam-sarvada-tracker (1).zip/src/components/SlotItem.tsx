import React, { useState } from 'react';
import { Check, Clock, MessageSquare, AlertCircle, ExternalLink, HardDrive } from 'lucide-react';
import { PostSlot } from '../types';
import { getSlotStatus } from '../utils/time';

interface SlotItemProps {
  slot: PostSlot;
  currentTime: Date;
  onToggle: (id: string, checked: boolean) => void;
  onUpdateNote: (id: string, note: string) => void;
  accentColor: string; // 'emerald' | 'sky' | 'rose'
}

export const SlotItem: React.FC<SlotItemProps> = ({
  slot,
  currentTime,
  onToggle,
  onUpdateNote,
}) => {
  const [showNoteInput, setShowNoteInput] = useState(Boolean(slot.note));
  const status = getSlotStatus(slot.time, slot.completed, currentTime);

  // Check if note contains a link or Google Drive link
  const urlMatch = slot.note?.match(/https?:\/\/[^\s]+/i);
  const detectedUrl = urlMatch ? urlMatch[0] : null;
  const isGoogleDrive = detectedUrl?.includes('drive.google.com');

  return (
    <div
      id={`slot-row-${slot.id}`}
      className={`group transition-all duration-200 border-b border-slate-700/60 last:border-b-0 px-3 py-3.5 rounded-lg ${
        slot.completed
          ? 'bg-emerald-950/20 text-slate-300'
          : status === 'active'
          ? 'bg-sky-950/30 ring-1 ring-sky-500/40'
          : 'hover:bg-slate-800/40 text-slate-100'
      }`}
    >
      <div className="flex items-center justify-between gap-3">
        <label
          htmlFor={slot.id}
          className="flex items-center gap-3.5 flex-1 cursor-pointer select-none"
        >
          {/* Custom Styled Checkbox matching native checkbox input */}
          <div className="relative flex items-center justify-center">
            <input
              type="checkbox"
              id={slot.id}
              checked={slot.completed}
              onChange={(e) => onToggle(slot.id, e.target.checked)}
              className="sr-only"
            />
            <div
              id={`checkbox-box-${slot.id}`}
              className={`w-6 h-6 rounded-md border flex items-center justify-center transition-all ${
                slot.completed
                  ? 'bg-emerald-500 border-emerald-400 text-slate-950 shadow-sm shadow-emerald-500/30'
                  : status === 'active'
                  ? 'border-sky-400 bg-slate-800 hover:border-sky-300'
                  : 'border-slate-500/70 bg-slate-800/80 group-hover:border-slate-400'
              }`}
            >
              {slot.completed && <Check className="w-4 h-4 stroke-[3]" />}
            </div>
          </div>

          {/* Time & Title info */}
          <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3 flex-1 min-w-0">
            <span
              className={`font-medium tracking-wide text-base ${
                slot.completed
                  ? 'line-through text-slate-400 decoration-slate-500'
                  : 'text-slate-100'
              }`}
            >
              {slot.time}
            </span>

            {slot.note && !showNoteInput && (
              <span className="text-xs text-slate-400 truncate max-w-[200px] bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700/50">
                {slot.note}
              </span>
            )}
          </div>
        </label>

        {/* Right Status Badges & Quick Note Trigger */}
        <div className="flex items-center gap-2">
          {detectedUrl && (
            <a
              href={detectedUrl}
              target="_blank"
              rel="noopener noreferrer"
              title={isGoogleDrive ? "Open video file in Google Drive" : "Open link"}
              className="flex items-center gap-1 px-2 py-0.5 text-xs rounded bg-sky-950/60 hover:bg-sky-900/80 text-sky-300 border border-sky-600/40 transition-colors"
            >
              {isGoogleDrive ? (
                <HardDrive className="w-3 h-3 text-emerald-400" />
              ) : (
                <ExternalLink className="w-3 h-3 text-sky-400" />
              )}
              <span>{isGoogleDrive ? 'Drive' : 'Link'}</span>
            </a>
          )}

          {slot.completed ? (
            <span
              id={`badge-done-${slot.id}`}
              className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 whitespace-nowrap"
            >
              {slot.completedAt ? `Done ${slot.completedAt}` : 'Done'}
            </span>
          ) : status === 'active' ? (
            <span
              id={`badge-now-${slot.id}`}
              className="flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full bg-sky-500/20 text-sky-300 border border-sky-500/40 animate-pulse whitespace-nowrap"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-sky-400" />
              Due Now
            </span>
          ) : status === 'passed' ? (
            <span
              id={`badge-passed-${slot.id}`}
              className="flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300/80 border border-amber-500/20 whitespace-nowrap"
            >
              <AlertCircle className="w-3 h-3" />
              Past Due
            </span>
          ) : (
            <span
              id={`badge-sched-${slot.id}`}
              className="flex items-center gap-1 text-xs text-slate-400 px-2 py-0.5 whitespace-nowrap"
            >
              <Clock className="w-3 h-3 text-slate-500" />
              Scheduled
            </span>
          )}

          <button
            type="button"
            id={`btn-note-${slot.id}`}
            onClick={() => setShowNoteInput(!showNoteInput)}
            title={showNoteInput ? 'Hide note' : 'Add video title or Drive link'}
            className={`p-1.5 rounded hover:bg-slate-700/60 transition-colors text-slate-400 hover:text-slate-200 ${
              slot.note ? 'text-sky-400 bg-sky-950/40' : ''
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Collapsible Quick Note/Caption Input with Drive link helper */}
      {showNoteInput && (
        <div className="mt-2 pl-9 pr-1 flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <input
            type="text"
            id={`input-note-${slot.id}`}
            value={slot.note || ''}
            onChange={(e) => onUpdateNote(slot.id, e.target.value)}
            placeholder="Video title or Google Drive link (e.g. drive.google.com/...)..."
            className="flex-1 text-xs bg-slate-900/90 text-slate-200 placeholder-slate-500 px-2.5 py-1.5 rounded border border-slate-700 focus:outline-none focus:border-sky-500"
          />
          <a
            href="https://drive.google.com"
            target="_blank"
            rel="noopener noreferrer"
            title="Open Google Drive to copy video link"
            className="flex items-center justify-center gap-1 text-xs px-2.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-600 transition-colors"
          >
            <HardDrive className="w-3 h-3 text-emerald-400" />
            <span>Open Drive</span>
          </a>
        </div>
      )}
    </div>
  );
};
