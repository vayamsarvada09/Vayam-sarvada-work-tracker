import React from 'react';
import { Flame, Clock, CalendarDays, CheckCircle2 } from 'lucide-react';
import { PostSlot } from '../types';
import { parseTimeToToday } from '../utils/time';

interface HeaderProps {
  currentTime: Date;
  allSlots: PostSlot[];
  streak: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentTime,
  allSlots,
  streak,
}) => {
  const total = allSlots.length;
  const completed = allSlots.filter((s) => s.completed).length;
  const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;
  const isAllComplete = completed === total && total > 0;

  // Format date and time
  const timeFormatted = currentTime.toLocaleTimeString([], {
    hour: 'numeric',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });

  const dateFormatted = currentTime.toLocaleDateString([], {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });

  // Find next uncompleted slot
  const uncompletedSlots = allSlots
    .filter((s) => !s.completed)
    .sort((a, b) => {
      const timeA = parseTimeToToday(a.time, currentTime).getTime();
      const timeB = parseTimeToToday(b.time, currentTime).getTime();
      return timeA - timeB;
    });

  const nextSlot = uncompletedSlots.find((s) => {
    const slotTime = parseTimeToToday(s.time, currentTime).getTime();
    return slotTime >= currentTime.getTime() - 15 * 60 * 1000;
  }) || uncompletedSlots[0];

  return (
    <header className="mb-6">
      {/* Brand Title and Top Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-sky-400 tracking-tight">
              Vayam Sarvada Post Tracker
            </h1>
          </div>
          <p className="text-sm text-slate-400 mt-0.5">
            Daily content release schedule for Reels & Shorts
          </p>
        </div>

        {/* Live Clock & Streak Badge */}
        <div className="flex items-center gap-2.5">
          <div
            id="streak-badge"
            className="flex items-center gap-1.5 bg-amber-500/10 text-amber-300 border border-amber-500/30 px-3 py-1.5 rounded-lg text-xs font-semibold"
            title="Consecutive days with all scheduled posts completed"
          >
            <Flame className="w-4 h-4 text-amber-400 fill-amber-400/30" />
            <span>{streak} Day Streak</span>
          </div>

          <div
            id="live-clock"
            className="flex items-center gap-2 bg-slate-800/90 text-slate-200 border border-slate-700/80 px-3 py-1.5 rounded-lg text-xs font-mono font-medium shadow-inner"
          >
            <CalendarDays className="w-3.5 h-3.5 text-sky-400" />
            <span>{dateFormatted}</span>
            <span className="text-slate-600">|</span>
            <Clock className="w-3.5 h-3.5 text-sky-400" />
            <span className="text-sky-300">{timeFormatted}</span>
          </div>
        </div>
      </div>

      {/* Progress Summary Card */}
      <div className="bg-slate-800/60 border border-slate-700/70 rounded-xl p-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2 text-sm">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-200">Today's Progress</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-700 text-slate-300">
              {completed} of {total} slots published
            </span>
          </div>

          {isAllComplete ? (
            <div className="flex items-center gap-1 text-emerald-400 text-xs font-semibold">
              <CheckCircle2 className="w-4 h-4" />
              All posts completed for today!
            </div>
          ) : nextSlot ? (
            <div className="text-xs text-sky-300 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
              <span>Next up:</span>
              <strong className="font-semibold text-slate-100">{nextSlot.time}</strong>
              <span className="text-slate-400">
                ({nextSlot.platform === 'insta' ? 'Reels' : 'Shorts'})
              </span>
            </div>
          ) : null}
        </div>

        {/* Global Progress Bar */}
        <div className="w-full bg-slate-900/80 h-3 rounded-full overflow-hidden p-0.5 border border-slate-700/60">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              isAllComplete
                ? 'bg-gradient-to-r from-emerald-500 to-teal-400 shadow-sm shadow-emerald-500/50'
                : 'bg-gradient-to-r from-sky-500 via-indigo-500 to-rose-500'
            }`}
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>
    </header>
  );
};
